# 🔵 Segurança Defensiva (Blue Team)

Foco: defesa, monitoramento, proteção e resposta a incidentes.

## Subáreas
- Operações de Segurança: SOC, SIEM/SOAR, Threat Hunting, Threat Intel
- Resposta a Incidentes e Forense: CSIRT, forense digital
- Infraestrutura e Redes: firewalls, EDR/XDR, NAC
- Segurança em Nuvem: CSPM, CNAPP, IAM
- Segurança de Aplicações: AppSec, API, Containers

## Principais Cargos
| Cargo | Nível | Descrição breve |
|-------|-------|------------------|
| Analista SOC | Júnior–Pleno | Monitora alertas, investiga incidentes |
| Engenheiro de Segurança em Nuvem | Pleno–Sênior | Implementa controles de segurança em nuvem |
| Threat Hunter | Sênior | Caça ameaças avançadas |
| Analista Forense | Pleno–Sênior | Realiza análises pós-incidente |
| Especialista SIEM/SOAR | Pleno–Sênior | Automatiza detecções e respostas |
