# 🔴 Segurança Ofensiva (Red Team)

Foco em testes, exploração e simulações de ataque.
