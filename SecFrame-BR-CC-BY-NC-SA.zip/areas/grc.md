# 🏛 Governança, Risco e Compliance (GRC / White Team)

Foco em estratégia, políticas, conformidade e gestão de riscos.
