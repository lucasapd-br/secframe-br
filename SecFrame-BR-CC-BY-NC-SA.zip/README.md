# 📌 SecFrame BR

Framework brasileiro para padronização de cargos e áreas de Segurança da Informação.
