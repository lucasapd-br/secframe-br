# ☁️ Engenheiro de Segurança em Nuvem

## Identificação
- Área: Blue Team – Segurança em Nuvem
- Nível: Pleno / Sênior
- Tipo: Técnica / Engenharia

## Missão Principal
Garantir que os ambientes de nuvem da organização sejam seguros, resilientes e aderentes às melhores práticas.

## Responsabilidades
- Projetar e implementar controles em AWS, Azure e GCP
- Automatizar verificações de postura de segurança (CSPM, IaC)
- Apoiar resposta a incidentes em nuvem
- Colaborar com DevOps e Arquitetura para segurança desde o design

## Competências
**Técnicas obrigatórias:**
- IAM, redes e serviços em nuvem
- CSPM e CNAPP
- Terraform / ARM / CloudFormation

**Desejáveis:**
- Certificações (AWS Sec Specialty, AZ-500, CCSK)
- Python ou PowerShell
- Kubernetes Security

**Soft skills:**
- Comunicação clara
- Pensamento analítico

## Requisitos
- 3+ anos de experiência em segurança/cloud
- Conhecimento multi-cloud
- Inglês técnico intermediário

## Frameworks de Referência
- NIST NICE: PR-CDA-001, PR-IN-001
- ENISA: Cloud Operations Security
- SFIA: SCTY, CLDS, INAS
